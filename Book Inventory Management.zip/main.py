# -*- coding: utf-8 -*-
from Library.data_read import csv_read
from Library.data_display import csv_display
from Library.data_update import csv_update, csv_delete, csv_add
from Library.data_search import csv_search

def main():
    Data = csv_read()
    Input = ""
    while Input != "quit":
        print()
        Input = input("Type add, search, display, update, delete or quit: ")
        print()
        if Input == "add":
            Title = input("Type a book title: ")
            Author = input("Type a name of an author: ")
            Year = input("Type when the book was released: ")
            Quantity = input("Type how many books you have in store: ")
            
            Data = csv_add(Title, Author, Year, Quantity, Data)
        elif Input == "search":
            Input = input('If you want to search by a name of a book type "1" or "book". For - author type "2" or "author": ')
            csv_search(Input, Data)
        elif Input == "display":
            csv_display(Data)
        elif Input == "update":
            Title = input("Type a title of a book: ")
            Author = input("Type an author of a book: ")
            Quantity = input("Type a quantity of a chosen book: ")
            
            csv_update(Title, Author, Quantity, Data)
        elif Input == "delete":
            Title = input("Type a title of a book you want to delete: ")
            Author = input("Type an author of a book: ")
            Year = input("Type an year of a book: ")
            
            csv_delete(Title, Author, Year, Data)
        elif Input == "quit":
            print("Stopping...")
        else:
            print("Sorry, such command does not exist. Please try again.")

main()

"""
Task list:
1. Add a new book to the inventory (title, author, year, quantity). +
2. Search for a book by title or author and display its details. +
3. Display the entire book inventory. +
4. Update the quantity of a book. +
5. Delete a book from the inventory. +
"""