# -*- coding: utf-8 -*-
from Library.data_dismantle import csv_dismantle

def csv_search(Input, Data):
    info = [[]]
    if Input == "1" or Input == "book":
        
        Title = input("Type a book title you want to search: ")
        
        for row in Data:
            if row[0] == Title:
                info.append([row])
    elif Input == "2" or Input == "author":
        Author = input("Type an author you want to search: ")
        
        for row in Data:
            if row[1] == Author:
                info.append([row])
    else:
        print("There is no such command.")
        return ""
    csv_dismantle(info)
    return info