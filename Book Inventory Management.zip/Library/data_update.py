# -*- coding: utf-8 -*-
from Library.data_write import csv_write

def csv_update(Title, Author, Quantity, Data):
    for row in Data:
        if row[0] == Title and row[1] == Author:
            row[3] = Quantity
            break
    csv_write(Data)

def csv_delete(Title, Author, Year, Data):
    for row in Data:
        if row[0] == Title and row[1] == Author and row[2] == Year:
            Data.remove([row[0], row[1], row[2], row[3]])
    csv_write(Data)
    
def csv_add(Title, Author, Year, Quantity, Data):
    Data.append([Title, Author, Year, Quantity])
    csv_write(Data)
    return Data