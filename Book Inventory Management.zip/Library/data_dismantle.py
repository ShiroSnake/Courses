# -*- coding: utf-8 -*-

def csv_dismantle(info):
    for row in info:
        for i in row:
            print('Title: ' + i[0] + '. Author: ' +  i[1] + '. Year: ' + i[2] + '. Quantity: ' + i[3] + '.')