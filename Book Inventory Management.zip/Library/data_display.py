# -*- coding: utf-8 -*-

def csv_display(Data):
    for row in Data:
        if row == Data[0]:
            continue
        print('Title: ' + row[0] + '. Author: ' +  row[1] + '. Year: ' + row[2] + '. Quantity: ' + row[3] + '.')