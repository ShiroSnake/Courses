# -*- coding: utf-8 -*-

def main():
    print()
    read_quiz()
    
def read_quiz():
    with open("Quiz.txt", 'r') as file:
        reader = file.readlines()
        for rows in reader:
            if "Answer" in rows:
                Guess = input("Choose an answer: A, B, C or D: ")
                rep = rows.split(":")[1].strip().lower()
                if Guess == rep:
                    print("Teisingai!")
                else:
                    print("Neteisingai!")
            
            print(rows)


main()


